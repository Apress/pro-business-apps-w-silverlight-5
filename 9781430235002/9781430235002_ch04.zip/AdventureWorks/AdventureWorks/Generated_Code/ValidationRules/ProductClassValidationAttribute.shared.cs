﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace AdventureWorks.Web.ValidationRules
{
    public class ProductClassValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string productClass = value.ToString();
            bool isValid = false;

            string[] validClasses = new string[] { "H", "M", "L", "" };
            isValid = validClasses.Contains(productClass.ToUpper());

            return isValid ? ValidationResult.Success : new ValidationResult("The class is invalid");
        }
    }
}