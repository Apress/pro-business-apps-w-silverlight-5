CHAPTER 4 SAMPLE CODE
---------------------

This solution accompanies Chapter 4 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Creating an Entity Model
- Creating the ProductService Domain Service
- Creating a Custom Property Validation Attribute
- Creating a Custom Class Validation Attribute
- Creating the Presentation Model Class
- Populating and Exposing Your Presentation Model Types
- Making Your Presentation Model Types Editable
- Returning Auto-Generated Property Values Back to the Client
- Creating a Shared Code File
- Configuring an Entity Model to Check for Concurrency Violations

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.