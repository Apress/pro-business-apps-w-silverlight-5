﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace AdventureWorks.Web.ValidationRules
{
    public class ProductClassValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            bool isValid = true;

            if (value != null)
            {
                string productClass = value.ToString();

                string[] validClasses = new string[] { "H", "M", "L", "" };
                isValid = validClasses.Contains(productClass.ToUpper());
            }

            // NOTE: The code in the book didn't specify a value for the 'memberNames' parameter. However, this
            // is required in order for any controls mapped to properties decorated with this validation attribute
            // to display that there is an error.
            return isValid ? ValidationResult.Success : new ValidationResult("The class is invalid", new string[] { validationContext.MemberName });
        }
    }
}