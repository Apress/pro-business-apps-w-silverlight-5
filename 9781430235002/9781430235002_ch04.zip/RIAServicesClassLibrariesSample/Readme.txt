CHAPTER 4 SAMPLE CODE
---------------------

This solution accompanies Chapter 4 of Pro Business Applications with Silverlight 5, and
includes the code for the workshop titled "Using WCF RIA Services Class Libraries".