﻿using System.ServiceModel.DomainServices.Client.ApplicationServices;
using AdventureWorks.Web;

namespace AdventureWorks
{
    public sealed partial class WebContext : WebContextBase
    {
        partial void OnCreated();

        public WebContext()
        {
            this.OnCreated();
        }

        public new static WebContext Current
        {
            get
            {
                return ((WebContext)(WebContextBase.Current));
            }
        }

        public new User User
        {
            get
            {
                return ((User)(base.User));
            }
        }
    }
}
