CHAPTER 13 SAMPLE CODE
----------------------

This solution accompanies Chapter 13 of Pro Business Applications with Silverlight 5.
Previous chapters were already using a simple form of the MVVM design pattern, but
this sample updates the view models in the following ways:

- view models now inherit from a base view model that provides commonly used functionality (except the 
  LoginViewModel, which is kept the same as listed in the book for now)
- made the ProductListViewModel design-time safe, and hooked it up to the view in XAML rather than code
- show error messages using the MVVM compliant techniques discussed in the chapter
- the Add button in the product list view uses an action to navigate to another page rather than code-behind


This sample includes code for the following workshops in the chapter:

- Creating the LoginView View
- Creating the LoginViewModel ViewModel Class
- Connecting the ViewModel to the View
- Consuming Data from the ViewModel in the View
- Invoking the Login Operation (Command) on the ViewModel
- Responding to the ViewModel�s LoginSuccessful Event in the View

Note that the code used in this sample for the LoginView scenario covered in these workshops
is *slightly* different from that in the book. Primarily, it uses AdventureWorks namesapces,
and is actually fully functional - it validates the user from the users on the server, and
navigates to the product list if the login is successful.


In addition, code for various actions that you might find useful in your projects 
can be found in the Behaviors folder of the AdventureWorks project.


The security configured in chapter 8 has been disabled so that it doesn't interfere with you 
playing with the samples.

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.