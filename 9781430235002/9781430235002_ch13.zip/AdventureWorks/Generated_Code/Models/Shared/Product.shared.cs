﻿namespace AdventureWorks.Web
{
    public partial class Product
    {
        public decimal ProfitMargin
        {
            get { return ListPrice - StandardCost; }
        }
    }
}