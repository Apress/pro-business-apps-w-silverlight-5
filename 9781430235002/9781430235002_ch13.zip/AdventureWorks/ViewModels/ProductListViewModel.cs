﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ServiceModel.DomainServices.Client;
using AdventureWorks.Web;
using AdventureWorks.Web.Models;
using AdventureWorks.Web.Services;
using Microsoft.Windows.Data.DomainServices;
using SimpleMVVM;

namespace AdventureWorks.ViewModels
{
    public class ProductListViewModel : ViewModelBase
    {
        private string _searchText = "";
        private ProductSummaryContext _context = new ProductSummaryContext();

        public IEnumerable<ProductSummary> Products { get; set; }
        public DomainCollectionView ProductCollectionView { get; set; }

        public ProductListViewModel()
        {
            if (!IsDesignTimeMode)
            {
                Products = new EntityList<ProductSummary>(_context.ProductSummaries);
                var collectionViewLoader = new DomainCollectionViewLoader<ProductSummary>(LoadProductList, OnLoadProductListCompleted);
                ProductCollectionView = new DomainCollectionView<ProductSummary>(collectionViewLoader, Products);

                // Configures sorting
                SortDescription sortBy = new SortDescription("Name", ListSortDirection.Ascending);
                ProductCollectionView.SortDescriptions.Add(sortBy);

                // Configures grouping
                //PropertyGroupDescription groupBy = new PropertyGroupDescription("Model");
                //ProductCollectionView.GroupDescriptions.Add(groupBy);

                using (ProductCollectionView.DeferRefresh())
                {
                    ProductCollectionView.PageSize = 30;
                    ProductCollectionView.MoveToFirstPage();
                }
            }
        }

        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;

                using (ProductCollectionView.DeferRefresh())
                {
                    ProductCollectionView.MoveToFirstPage();
                }
            }
        }

        private LoadOperation<ProductSummary> LoadProductList()
        {
            IsBusy = true;

            EntityQuery<ProductSummary> query = _context.GetProductSummaryListQuery();
            query = query.Where(x => x.Name.Contains(_searchText));
            query = query.SortAndPageBy(ProductCollectionView);
            query.IncludeTotalCount = true;
            return _context.Load(query);
        }

        private void OnLoadProductListCompleted(LoadOperation<ProductSummary> op)
        {
            if (op.HasError)
            {
                // An event is raised indicating an error has occurred. The view can
                // then listen for this and show a message box in response.
                OnNotifyError("An error occurred loading the product:" + op.Error.Message);

                // So the error doesn't get thrown
                op.MarkErrorAsHandled();
            }
            else if (!op.IsCanceled)
            {
                ((EntityList<ProductSummary>)Products).Source = op.Entities;

                if (op.TotalEntityCount != -1)
                    ProductCollectionView.SetTotalItemCount(op.TotalEntityCount);
            }

            IsBusy = false;
        }
    }
}
