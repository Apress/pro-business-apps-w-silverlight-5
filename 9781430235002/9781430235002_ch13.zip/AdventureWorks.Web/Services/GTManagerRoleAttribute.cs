﻿using System.ComponentModel.DataAnnotations;

namespace AdventureWorks.Web.Services
{
    public class GTManagerRoleAttribute : AuthorizationAttribute
    {
        protected override AuthorizationResult IsAuthorized(System.Security.Principal.IPrincipal principal, AuthorizationContext authorizationContext)
        {
            if (principal.IsInRole("Administrators") || principal.IsInRole("Managers"))
                return AuthorizationResult.Allowed;
            else
                return new AuthorizationResult(
                    "You do not have sufficient rights to perform this operation.");
        }
    }
}