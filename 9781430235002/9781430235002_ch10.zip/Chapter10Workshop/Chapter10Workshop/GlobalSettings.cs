﻿namespace Chapter10Workshop
{
    public class GlobalSettings
    {
        public static string CompanyName
        {
            get
            {
                // Hardcoded value for demonstration purposes
                return "Apress";
            }
        }
    }
}
