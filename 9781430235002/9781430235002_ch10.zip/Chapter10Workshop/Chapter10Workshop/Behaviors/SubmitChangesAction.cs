﻿using System.Windows.Controls;
using System.Windows.Interactivity;

namespace Chapter10Workshop.Behaviors
{
    public class SubmitChangesAction : TargetedTriggerAction<DomainDataSource>
    {
        protected override void Invoke(object parameter)
        {
            Target.SubmitChanges();
        }
    }
}
