﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Interactivity;

namespace Chapter10Workshop.Behaviors
{
    public class ButtonClickTrigger : TriggerBase<Button>
    {
        protected override void OnAttached()
        {
            base.OnAttached();

            AssociatedObject.Click += new RoutedEventHandler(AssociatedObject_Click);
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();

            AssociatedObject.Click -= new RoutedEventHandler(AssociatedObject_Click);
        }

        private void AssociatedObject_Click(object sender, RoutedEventArgs e)
        {
            InvokeActions(null);
        }
    }
}
