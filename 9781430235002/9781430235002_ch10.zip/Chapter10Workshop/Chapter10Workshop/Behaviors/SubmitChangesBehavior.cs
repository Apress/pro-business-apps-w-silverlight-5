﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Interactivity;

namespace Chapter10Workshop.Behaviors
{
    public class SubmitChangesBehavior : Behavior<Button>
    {
        [CustomPropertyValueEditor(CustomPropertyValueEditor.ElementBinding)]
        public DomainDataSource TargetObject
        {
            get { return (DomainDataSource)GetValue(TargetObjectProperty); }
            set { SetValue(TargetObjectProperty, value); }
        }

        public static readonly DependencyProperty TargetObjectProperty =
            DependencyProperty.Register("TargetObject", typeof(DomainDataSource), typeof(SubmitChangesBehavior), null);

        protected override void OnAttached()
        {
            base.OnAttached();

            AssociatedObject.Click += new RoutedEventHandler(AssociatedObject_Click);
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();

            AssociatedObject.Click -= new RoutedEventHandler(AssociatedObject_Click);
        }

        private void AssociatedObject_Click(object sender, RoutedEventArgs e)
        {
            TargetObject.SubmitChanges();
        }
    }
}
