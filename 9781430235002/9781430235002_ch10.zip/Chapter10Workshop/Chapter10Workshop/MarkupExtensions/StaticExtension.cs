﻿using System;
using System.Reflection;
using System.Windows.Markup;

namespace Chapter10Workshop.MarkupExtensions
{
    public class StaticExtension : MarkupExtension
    { 
        public string Path { get; set; }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            object result = null;

            if (Path != null && Path.IndexOf('.') != 0)
            {
                // Split into qualified type and property name
                string typeName = Path.Substring(0, Path.LastIndexOf('.'));
                string propertyName = Path.Substring(Path.LastIndexOf('.') + 1);

                Type type = Type.GetType(typeName, false, false);

                if (type != null)
                {
                    FieldInfo field = type.GetField(propertyName, 
                        BindingFlags.Public | BindingFlags.Static);

                    if (field != null)
                    {
                        result = field.GetValue(null);
                    }
                    else
                    {
                        PropertyInfo property = type.GetProperty(propertyName, 
                            BindingFlags.Public | BindingFlags.Static);

                        if (property != null)
                            result = property.GetValue(null, null);
                    }
                }
            }

            return result;
        }
    }
}
