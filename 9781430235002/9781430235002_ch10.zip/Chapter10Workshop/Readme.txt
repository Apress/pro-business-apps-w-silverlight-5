CHAPTER 10 SAMPLE CODE
----------------------

This solution accompanies Chapter 10 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Implementing Triggers and Actions in XAML by Hand
- Writing Custom Triggers
- Creating and Using Custom Actions
- Creating and Using a Behavior
- Implementing the Custom Markup Extension

The custom markup extension workshop in the book had a few mistakes unfortunately. The
code here, however, works correctly.

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.