﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.ServiceModel.DomainServices.Client;
using AdventureWorks.Web.Services;
using AdventureWorks.Web;

namespace AdventureWorks.Views
{
    public partial class ProductListView_Code : Page
    {
        private ProductContext _context = null;

        public ProductListView_Code()
        {
            InitializeComponent();

            _context = new ProductContext();
            EntityQuery<Product> qry = _context.GetProductsQuery();
            qry = qry.Where(p => p.SellStartDate <= DateTime.Now);
            LoadOperation<Product> loadOperation = _context.Load(qry);
            productDataGrid.ItemsSource = loadOperation.Entities;
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            SubmitOperation submitOperation = _context.SubmitChanges();
        }
    }
}
