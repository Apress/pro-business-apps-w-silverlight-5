CHAPTER 5 SAMPLE CODE
---------------------

This solution accompanies Chapter 5 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Querying Data in XAML
- Querying Data in Code
- Specifying Query Criteria Using Lambda Expressions
- Submitting Changes via the DomainDataSource Control
- Submitting Changes via a Domain Context

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.