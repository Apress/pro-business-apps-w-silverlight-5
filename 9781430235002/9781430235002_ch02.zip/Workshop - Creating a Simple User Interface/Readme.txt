CHAPTER 2 SAMPLE CODE
---------------------

This is the solution to accompany the "Creating a Simple User Interface" workshop
in Chapter 2 of Pro Business Applications with Silverlight 5.