CHAPTER 3 SAMPLE CODE
---------------------

This solution accompanies Chapter 3 of Pro Business Applications with Silverlight 5, and
demonstrates Silverlight's Navigation Framework features. This solution also demonstrates 
some custom transitions. You can find the code for these at the end of the Styles.xaml
file, which is located in the Assets folder.