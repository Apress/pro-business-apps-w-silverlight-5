﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ServiceModel.DomainServices.Client;
using AdventureWorks.Web;
using AdventureWorks.Web.Models;
using AdventureWorks.Web.Services;
using Microsoft.Windows.Data.DomainServices;

namespace AdventureWorks.ViewModels
{
    public class ProductListViewModel : INotifyPropertyChanged
    {
        private string _searchText = "";
        private bool _isBusy = false;
        private ProductSummaryContext _context = new ProductSummaryContext();

        public IEnumerable<ProductSummary> Products { get; set; }
        public DomainCollectionView ProductCollectionView { get; set; }

        public ProductListViewModel()
        {
            Products = new EntityList<ProductSummary>(_context.ProductSummaries);
            var collectionViewLoader = new DomainCollectionViewLoader<ProductSummary>(LoadProductList, OnLoadProductListCompleted);
            ProductCollectionView = new DomainCollectionView<ProductSummary>(collectionViewLoader, Products);

            // Configures sorting
            SortDescription sortBy = new SortDescription("Name", ListSortDirection.Ascending);
            ProductCollectionView.SortDescriptions.Add(sortBy);

            // Configures grouping
            //PropertyGroupDescription groupBy = new PropertyGroupDescription("Model");
            //ProductCollectionView.GroupDescriptions.Add(groupBy);

            using (ProductCollectionView.DeferRefresh())
            {
                ProductCollectionView.PageSize = 30;
                ProductCollectionView.MoveToFirstPage();
            }
        }

        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;

                using (ProductCollectionView.DeferRefresh())
                {
                    ProductCollectionView.MoveToFirstPage();
                }
            }
        }

        public bool IsBusy
        {
            get { return _isBusy; }
            private set
            {
                _isBusy = value;

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("IsBusy"));
            }
        }

        private LoadOperation<ProductSummary> LoadProductList()
        {
            IsBusy = true;

            EntityQuery<ProductSummary> query = _context.GetProductSummaryListQuery();
            query = query.Where(x => x.Name.Contains(_searchText));
            query = query.SortAndPageBy(ProductCollectionView);
            query.IncludeTotalCount = true;
            return _context.Load(query);
        }

        private void OnLoadProductListCompleted(LoadOperation<ProductSummary> op)
        {
            if (op.HasError)
            {
                // Usually you will notify the user that the load failed here.
                // For now, we will show the error in a message box launched from this view model.
                // This strategy is NOT recommended in real applications, as you are violating the
                // separation of concerns principle by putting UI concerns in the view model, and
                // affecting the testability of the view model. Chapter 13 covers the MVVM design 
                // pattern, where we'll look at strategies for solving this problem. For now, we'll
                // just use message boxes here in the view model until we cover that subject.
                System.Windows.MessageBox.Show("An error occurred loading the product:" + op.Error.Message, "AdventureWorks", System.Windows.MessageBoxButton.OK);

                // So the error doesn't get thrown
                op.MarkErrorAsHandled();
            }
            else if (!op.IsCanceled)
            {
                ((EntityList<ProductSummary>)Products).Source = op.Entities;

                if (op.TotalEntityCount != -1)
                    ProductCollectionView.SetTotalItemCount(op.TotalEntityCount);
            }

            IsBusy = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
