﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ServiceModel.DomainServices.Client;
using System.Windows.Data;
using System.Windows.Input;
using AdventureWorks.Web;
using AdventureWorks.Web.Models;
using AdventureWorks.Web.Services;
using Microsoft.Windows.Data.DomainServices;
using SimpleMVVM;

namespace AdventureWorks.ViewModels
{
    public class EditProductsViewModel : INotifyPropertyChanged
    {
        private string _searchText = "";
        private bool _isBusy = false;
        private ProductContext _context = new ProductContext();

        public IEnumerable<Product> Products { get; set; }
        public DomainCollectionView ProductCollectionView { get; set; }

        public EditProductsViewModel()
        {
            Products = new EntityList<Product>(_context.Products);
            var collectionViewLoader = new DomainCollectionViewLoader<Product>(LoadProductList, OnLoadProductListCompleted);
            ProductCollectionView = new DomainCollectionView<Product>(collectionViewLoader, Products);

            // Configures sorting
            SortDescription sortBy = new SortDescription("Name", ListSortDirection.Ascending);
            ProductCollectionView.SortDescriptions.Add(sortBy);

            // Configures grouping
            //PropertyGroupDescription groupBy = new PropertyGroupDescription("Model");
            //ProductCollectionView.GroupDescriptions.Add(groupBy);

            using (ProductCollectionView.DeferRefresh())
            {
                ProductCollectionView.PageSize = 30;
                ProductCollectionView.MoveToFirstPage();
            }
        }

        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;

                using (ProductCollectionView.DeferRefresh())
                {
                    ProductCollectionView.MoveToFirstPage();
                }
            }
        }

        public bool IsBusy
        {
            get { return _isBusy; }
            private set
            {
                _isBusy = value;

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("IsBusy"));
            }
        }

        private LoadOperation<Product> LoadProductList()
        {
            IsBusy = true;

            EntityQuery<Product> query = _context.GetProductsQuery();
            query = query.Where(x => x.Name.Contains(_searchText));
            query = query.SortAndPageBy(ProductCollectionView);
            query.IncludeTotalCount = true;
            return _context.Load(query);
        }

        private void OnLoadProductListCompleted(LoadOperation<Product> op)
        {
            if (op.HasError)
            {
                // NOTE: You should add some logic for handling errors here, and mark
                //       the error as handled.
                // op.MarkErrorAsHandled();
            }
            else if (!op.IsCanceled)
            {
                ((EntityList<Product>)Products).Source = op.Entities;

                if (op.TotalEntityCount != -1)
                    ProductCollectionView.SetTotalItemCount(op.TotalEntityCount);
            }

            IsBusy = false;
        }

        public ICommand SubmitChangesCommand
        {
            get
            {
                return new DelegateCommand(SubmitChanges, (param) => true);
            }
        }

        public void SubmitChanges(object param)
        {
            IsBusy = true;

            SubmitOperation op = _context.SubmitChanges();
            op.Completed += Submit_Completed;
        }

        private void Submit_Completed(object sender, System.EventArgs e)
        {
            SubmitOperation op = sender as SubmitOperation;

            if (op.HasError)
            {
                DomainOperationException error = op.Error as DomainOperationException;

                switch (error.Status)
                {
                    case OperationErrorStatus.Conflicts:
                        // Handle concurrency violations

                        // Loop through the entities with concurrency violations
                        foreach (Product product in op.EntitiesInError)
                        {
                            EntityConflict conflictinfo = product.EntityConflict;
                            Product currentProduct = conflictinfo.CurrentEntity as Product;
                            Product originalProduct = conflictinfo.OriginalEntity as Product;
                            Product storeProduct = conflictinfo.StoreEntity as Product;

                            // Handle any conflicts automatically (if you wish)
                            // You can get the names of the properties whose value has changed
                            // from the conflictinfo.PropertyNames property

                            // Force the user's version to overwrite the server’s version
                            //product.EntityConflict.Resolve();
                        }

                        break;
                    case OperationErrorStatus.ServerError:
                        // Handle server errors
                        break;
                    case OperationErrorStatus.Unauthorized:
                        // Handle unauthorized domain operation access
                        break;
                    case OperationErrorStatus.ValidationFailed:
                        // Handle validation rule failures
                        break;
                    default:
                        // Handle other possible statuses
                        break;
                }

                // NOTE: You should add some logic for handling errors here, and mark
                //       the error as handled.
                // op.MarkErrorAsHandled();
            }

            IsBusy = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
