CHAPTER 7 SAMPLE CODE
---------------------

This solution accompanies Chapter 7 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Creating a Master/Details Screen (an alternatve version using the DomainCollectionView
  has also been included)

- Adding the DataForm Control to a View

A drill-through summary list + details screen has also been included in this sample.

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.


WARNING
-------

This is a note that frustratingly got left out of chapter 4 of the book, which affects
this sample:

------------------------------------------------------------------------------------------
NOTE: The�ModifiedDate�field on the�Products�table in the�AdventureWorks�database is of 
type�datetime, which acceptable when checking for concurrency violations due to multiple 
users editing the same record as demonstrated here, but will actually lead to concurrency 
issues when a user attempts to update a record twice. The problem stems from�.NET's�
DateTime�type being�more accurate than that of��SQL Server's�datetime�column type, which 
according to MSDN�is rounded to .000, .003, or .007 seconds. This means that when you 
store a date in SQL Server from .NET, that stored value will generally end up being 
slightly different to the date you attempted to store (by a few milliseconds). When the 
user saves the record again, the modified date for the record will be slightly different 
to the modified date stored in the database, leading to a concurrency violation being 
detected - despite there not being one. Therefore, although we've used a field of type�
datetime�to check for concurrency exceptions in this workshop for convenience sake 
(since the field already existed), you should never do so in practice. If you want to 
maintain row versions using a date, use a field of type�datetime2�instead, whose 
accuracy matches that of .NET'sDateTime�type.
------------------------------------------------------------------------------------------

The result of this is that if you attempt to save the details for a product twice,
without loading all the product details from the server again, you will get a
concurrency violation. To prevent this from happening, follow these steps:

1. Go into design-mode for the Products table, either in SQL Server Management Studio
   (right-click the table, and select Design from the context menu), or using the Server 
   Explorer tool window in Visual Studio (right-click the table and select Open Table
   Definition).

2. Delete the ModifiedDate column, and save the changes.

3. Add a new column named ModifiedDate, of type datetime2, and set these properties:

   - Allow Nulls - false
   - Default Value or Binding - GETDATE()

4. Save the changes.

5. Open the Entity Framework model. Right-click on the design surface, and select
   the Update Model from Database... item from the context menu. Press OK. Save
   the changes to the model.

Now when you save the details for a product twice, the precision of the date being
stored in the database will match that sent back to the Silverlight client, and you 
won't experience errant concurrency violation errors any longer.