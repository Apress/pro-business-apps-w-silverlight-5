﻿
namespace AdventureWorks.Web.Services
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Data;
    using System.Linq;
    using System.ServiceModel.DomainServices.EntityFramework;
    using System.ServiceModel.DomainServices.Hosting;
    using System.ServiceModel.DomainServices.Server;
    using AdventureWorks.Web;


    // [RequiresAuthentication]
    [EnableClientAccess()]
    public class DictionaryService : LinqToEntitiesDomainService<AdventureWorksEntities>
    {
        public IQueryable<ProductCategory> GetProductCategories()
        {
            return this.ObjectContext.ProductCategories.OrderBy(x => x.Name);
        }

        public IQueryable<ProductSubcategory> GetProductSubcategories(int parentCategoryID)
        {
            return this.ObjectContext.ProductSubcategories.Where(x => x.ProductCategoryID == parentCategoryID).OrderBy(x => x.Name);
        }

        public IQueryable<ProductModel> GetProductModels()
        {
            return this.ObjectContext.ProductModels.OrderBy(x => x.Name);
        }

        public IQueryable<UnitMeasure> GetUnitMeasures()
        {
            return this.ObjectContext.UnitMeasures.OrderBy(x => x.Name);
        }
    }
}


