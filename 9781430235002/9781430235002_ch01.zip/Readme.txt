CHAPTER 1 SAMPLE CODE
---------------------

This solution accompanies Chapter 1 of Pro Business Applications with Silverlight 5, and 
will be used as the base of most of the other workshops throughout the book. The
recommended project template modifications discussed in this chapter have been made 
to the AdventureWorksTestPage.html page.