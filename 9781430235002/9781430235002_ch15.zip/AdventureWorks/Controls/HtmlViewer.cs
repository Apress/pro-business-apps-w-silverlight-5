﻿using System;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;
using System.Windows.Media;
using System.ComponentModel;

namespace SilverlightLOBFramework.Controls.Layout
{
    // NOTE: When using this control, if you experience the browser resizing it madly, try going into the
    // host HTML page and changing the 'overflow' property of the 'html, body' style from 'auto' to 'hidden'.
    // It seems to be experienced in IE9.
    public partial class HtmlViewer : UserControl, IDisposable
    {
        #region Member Variables
        private HtmlElement _divElement = null;
        private HtmlElement _iframeElement = null;
        private WebBrowser _webBrowser = null;
        #endregion

        #region Constants
        private const string loadingHTML =
            "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">" +
            "<html xmlns=\"http://www.w3.org/1999/xhtml\">" +
                "<head />" +
                "<body>" +
                    "<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small; font-weight: bold; color: Navy; width: 100%; text-align: center; vertical-align: middle; top: 50%; position: absolute;\">" +
                        "Please wait - loading..." +
                    "</div>" +
                "</body>" +
            "</html>"; 
        #endregion

        #region Events
        /// <summary>
        /// Raised when the specified page has loaded.  Note that this
        /// event is not raised when the content is a PDF file
        /// </summary>
        public event EventHandler ContentLoadComplete;
        #endregion

        #region Constructor
        public HtmlViewer()
        {
            this.Loaded += new RoutedEventHandler(HtmlViewer_Loaded);
            this.LayoutUpdated += new EventHandler(HtmlViewer_LayoutUpdated);
        }
        #endregion

        #region Public Properties
        public string Url
        {
            get { return (string)GetValue(UrlProperty); }
            set { SetValue(UrlProperty, value); }
        }

        public static readonly DependencyProperty UrlProperty =
            DependencyProperty.Register("Url", typeof(string), typeof(HtmlViewer), new PropertyMetadata(OnUrlChanged));

        private static void OnUrlChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((HtmlViewer)d).Navigate(e.NewValue.ToString());
        }
        #endregion

        #region Event Handlers
        private void HtmlViewer_Loaded(object sender, RoutedEventArgs e)
        {
            if (!DesignerProperties.IsInDesignTool)
            {
                if (!Application.Current.IsRunningOutOfBrowser)
                {
                    EnsureWindowlessModeOn();
                    CreateIFrame();
                    PositionIFrame();
                }
                else
                {
                    _webBrowser = new WebBrowser();
                    _webBrowser.LoadCompleted += webBrowser_LoadCompleted;
                    this.Content = _webBrowser;
                }

                Page page = FindParentPage();

                if (page != null)
                    page.NavigationService.Navigating += NavigationService_Navigating;
            }
        }

        private void NavigationService_Navigating(object sender, System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            Dispose();
        }

        private void webBrowser_LoadCompleted(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            if (ContentLoadComplete != null)
                ContentLoadComplete(this, new EventArgs());
        }

        private void HtmlViewer_LayoutUpdated(object sender, EventArgs e)
        {
            if (!Application.Current.IsRunningOutOfBrowser)
                PositionIFrame();
        }

        private void iframeElement_PageLoaded(object sender, HtmlEventArgs e)
        {
            // NOTE: This event is never called for PDF files
            if (ContentLoadComplete != null)
                ContentLoadComplete(this, new EventArgs());
        }
        #endregion

        #region Private Functions
        private void EnsureWindowlessModeOn()
        {
            // Throw an exception if windowless mode isn't on, as the iframe
            // will be hidden behind the Silverlight plugin if it is
            HtmlElement silverlightObject = HtmlPage.Plugin;
            bool isWindowless = false;

            foreach (HtmlElement param in silverlightObject.Children)
            {
                if (param.TagName == "param")
                {
                    string name = param.GetAttribute("name");
                    string value = param.GetAttribute("value");

                    if (name == "Windowless")
                    {
                        isWindowless = Convert.ToBoolean(value);
                        break;
                    }
                }
            }

            if (!isWindowless)
                throw new Exception("The Silverlight plugin must be in windowless mode to use this control");
        }

        private void CreateIFrame()
        {
            // Create an iframe in the underlying aspx page to host
            // the given html content
            _divElement = HtmlPage.Document.CreateElement("div");
            _divElement.Id = "HtmlFrameDiv";
            _divElement.SetStyleAttribute("position", "absolute");
            _divElement.SetStyleAttribute("z-index", "99");

            _iframeElement = HtmlPage.Document.CreateElement("iframe");
            _iframeElement.Id = "HtmlFrame";
            _iframeElement.SetAttribute("scrolling", "no");
            _iframeElement.SetAttribute("frameborder", "0");
            _iframeElement.AttachEvent("onload", new EventHandler<HtmlEventArgs>(iframeElement_PageLoaded));
            
            HtmlElement formElement = HtmlPage.Document.GetElementsByTagName("form")[0] as HtmlElement;
            formElement.AppendChild(_divElement);

            _divElement.AppendChild(_iframeElement);

            // Add some HTML to the iframe before requesting the document
            // to indicate that it is loading
            HtmlWindow contentWindow = _iframeElement.GetProperty("contentWindow") as HtmlWindow;
            HtmlDocument document = contentWindow.GetProperty("document") as HtmlDocument;

            // Write the html to display to the document
            document.Invoke("open", null);
            document.Invoke("write", loadingHTML);
            document.Invoke("close", null);

            if (Url != null && Url.Length != 0)
                contentWindow.Navigate(new Uri(Url));
        }

        private void PositionIFrame()
        {
            // Fill the area of this control with the iframe
            if (_iframeElement != null && this.ActualHeight != 0)
            {
                double width = this.ActualWidth;
                double height = this.ActualHeight;
                
                GeneralTransform gt = this.TransformToVisual(Application.Current.RootVisual);
                Point pos = gt.Transform(new Point(0, 0));
                _divElement.SetStyleAttribute("left", pos.X.ToString() + "px");
                _divElement.SetStyleAttribute("top", pos.Y.ToString() + "px");
                _divElement.SetStyleAttribute("width", width.ToString() + "px");
                _divElement.SetStyleAttribute("height", height.ToString() + "px");

                _iframeElement.SetStyleAttribute("width", width.ToString() + "px");
                _iframeElement.SetStyleAttribute("height", height.ToString() + "px");
            }
        }

        private void DestroyIFrame()
        {
            // Remove the iframe from the underlying aspx page
            if (_divElement != null)
            {
                _divElement.Parent.RemoveChild(_divElement);
                _divElement = null;
                _iframeElement = null;
            }
        }

        private void Navigate(string url)
        {
            if (Application.Current.IsRunningOutOfBrowser)
            {
                if (_webBrowser != null)
                {
                    _webBrowser.Navigate(new Uri(url));
                }
            }
            else
            {
                if (_iframeElement != null)
                {
                    HtmlWindow contentWindow = _iframeElement.GetProperty("contentWindow") as HtmlWindow;
                    contentWindow.AttachEvent("onload", new EventHandler<HtmlEventArgs>(iframeElement_PageLoaded));
                    contentWindow.Navigate(new Uri(url));
                }
            }
        }

        private Page FindParentPage()
        {
            DependencyObject parent = VisualTreeHelper.GetParent(this);

            while (parent != null && !(parent is Page))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }

            return parent as Page;
        }
        #endregion

        #region Public Functions
        public void Dispose()
        {
            DestroyIFrame();
        } 
        #endregion
    }
}
