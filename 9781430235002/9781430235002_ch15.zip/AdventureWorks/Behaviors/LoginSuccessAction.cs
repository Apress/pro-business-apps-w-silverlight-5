﻿using System;
using System.Windows;
using System.Windows.Interactivity;

namespace AdventureWorks.Behaviors
{
    public class LoginSuccessAction : TriggerAction<UIElement>
    {
        protected override void Invoke(object parameter)
        {
            MessageBox.Show("Login successful!");
        }
    }
}
