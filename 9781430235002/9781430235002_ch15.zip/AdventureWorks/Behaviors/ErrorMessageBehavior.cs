﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Interactivity;
using SimpleMVVM;

namespace AdventureWorks.Behaviors
{
    /// <summary>
    /// This behavior listens to an object for an event to be raised. When that event
    /// is raised, a message box will be displayed with a given error message.  Note that
    /// error events must be of the type EventHandler<ErrorEventArgs> for this behavior
    /// to work.
    /// </summary>
    public class ErrorMessageBehavior : Behavior<FrameworkElement>
    {
        protected override void OnAttached()
        {
            base.OnAttached();

            if (EventSource != null && EventName != null)
            {
                var eventHandlerDelegate = new EventHandler<ErrorEventArgs>(ShowErrorMessage);
                EventInfo eventInfo = EventSource.GetType().GetEvent(EventName);
                eventInfo.AddEventHandler(EventSource, eventHandlerDelegate);
            }
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();

            if (EventSource != null && EventName != null)
            {
                var eventHandlerDelegate = new EventHandler<ErrorEventArgs>(ShowErrorMessage);
                EventInfo eventInfo = EventSource.GetType().GetEvent(EventName);
                eventInfo.RemoveEventHandler(EventSource, eventHandlerDelegate);
            }
        }

        private void ShowErrorMessage(object sender, ErrorEventArgs e)
        {
            MessageBox.Show(e.ErrorMessage, Caption ?? "", MessageBoxButton.OK);
        }


        public string Caption
        {
            get { return (string)GetValue(CaptionProperty); }
            set { SetValue(CaptionProperty, value); }
        }

        public static readonly DependencyProperty CaptionProperty =
            DependencyProperty.Register("Caption", typeof(string), typeof(ErrorMessageBehavior), null);


        public object EventSource
        {
            get { return GetValue(EventSourceProperty); }
            set { SetValue(EventSourceProperty, value); }
        }

        public static readonly DependencyProperty EventSourceProperty =
            DependencyProperty.Register("EventSource", typeof(object), typeof(ErrorMessageBehavior), null);


        public string EventName
        {
            get { return (string)GetValue(EventNameProperty); }
            set { SetValue(EventNameProperty, value); }
        }

        public static readonly DependencyProperty EventNameProperty =
            DependencyProperty.Register("EventName", typeof(string), typeof(ErrorMessageBehavior), null);
    }
}
