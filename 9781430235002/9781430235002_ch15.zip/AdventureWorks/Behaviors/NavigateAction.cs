﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interactivity;
using System.Windows.Media;

namespace AdventureWorks.Behaviors
{
    public class NavigateAction : TriggerAction<UIElement>
    {
        public String Url
        {
            get { return (String)GetValue(UrlProperty); }
            set { SetValue(UrlProperty, value); }
        }

        public static readonly DependencyProperty UrlProperty =
            DependencyProperty.Register("Url", typeof(String),
                                        typeof(NavigateAction), null);

        protected override void Invoke(object parameter)
        {
            Frame frame = FindAncestorOfType(this.AssociatedObject, 
                                             typeof(Frame)) as Frame;
            
            if (frame != null) 
                frame.Navigate(new Uri(Url, UriKind.Relative));
        }

        public static DependencyObject FindAncestorOfType(DependencyObject element, 
                                                          Type locateType)
        {
            DependencyObject parent = element;

            do
            {
                parent = VisualTreeHelper.GetParent(parent);

                if (parent != null && parent.GetType() == locateType)
                    return parent;
            }
            while (parent != null);

            return null;
        }
    }
}
