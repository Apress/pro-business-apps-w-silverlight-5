﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Interactivity;

namespace AdventureWorks.Behaviors
{
    public class CloseChildWindowAction : TriggerAction<ChildWindow>
    {
        public bool? Result
        {
            get { return (bool?)GetValue(ResultProperty); }
            set { SetValue(ResultProperty, value); }
        }

        public static readonly DependencyProperty ResultProperty =
            DependencyProperty.Register("Result", typeof(bool?), 
                                        typeof(CloseChildWindowAction), null);
                
        protected override void Invoke(object parameter)
        {
            AssociatedObject.DialogResult = Result ?? true;
        }
    }
}
