﻿using System.Windows.Controls;
using System.Windows.Interactivity;

namespace AdventureWorks.Behaviors
{
    public class SetFocusAction : TargetedTriggerAction<Control>
    {
        protected override void Invoke(object parameter)
        {
            if (Target != null)
                Target.Focus();
        }
    }
}
