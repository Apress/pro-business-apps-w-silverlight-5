CHAPTER 15 SAMPLE CODE
----------------------

This solution accompanies Chapter 15 of Pro Business Applications with Silverlight 5.
This sample includes code for the following workshops in the chapter:

- Printing a Screen (see ProductDetailsView view)
- Printing a Report Created in Code (see ProductListView view)
- Obtaining Data to Populate the Report
- Creating a Report Renderer
- Creating the Report HTTP Handler
- Using the HtmlViewer Control
- Implementing the PivotViewer Control
- Applying an Item Adorner to Trading Cards


The security configured in chapter 8 has been disabled so that it doesn't interfere with you 
playing with the samples.

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.