﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AdventureWorks.Web.Models
{
    public class ProductSummary
    {
        [Key]
        [Editable(false)]
        public int ID { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
        public decimal ListPrice { get; set; }
        public byte[] ThumbnailPhoto { get; set; }
        public int? QuantityAvailable { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public string Model { get; set; }
        public bool MakeFlag { get; set; }

        [ConcurrencyCheck]
        public DateTime ModifiedDate { get; set; }
    }
}