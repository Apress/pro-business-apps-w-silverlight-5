﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using AdventureWorks.ViewModels;
using AdventureWorks.Web.Models;
using System.Windows.Data;

namespace AdventureWorks.Views
{
    public partial class ProductListView_CollectionViewSource : Page
    {
        public ProductListView_CollectionViewSource()
        {
            InitializeComponent();

            this.DataContext = new ProductListViewModel();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void productCollectionView_Filter(object sender, FilterEventArgs e)
        {
            e.Accepted = ((ProductSummary)e.Item).Name.IndexOf(SearchTextBox.Text, StringComparison.InvariantCultureIgnoreCase) != -1;
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var cvs = this.Resources["productCollectionView"] as CollectionViewSource;
            cvs.View.Refresh();
        }
    }
}
