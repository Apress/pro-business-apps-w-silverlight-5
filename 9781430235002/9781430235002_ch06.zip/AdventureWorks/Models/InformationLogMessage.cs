﻿namespace AdventureWorks.Models
{
    public class InformationLogMessage : LogMessage
    {

    }
}
