﻿namespace AdventureWorks.Models
{
    public class ErrorLogMessage : LogMessage
    {

    }
}
