﻿namespace AdventureWorks.Models
{
    public class WarningLogMessage : LogMessage
    {

    }
}
