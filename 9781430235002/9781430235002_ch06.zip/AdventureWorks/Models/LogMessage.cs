﻿namespace AdventureWorks.Models
{
    public class LogMessage
    {
        public string Message { get; set; }
    }
}
