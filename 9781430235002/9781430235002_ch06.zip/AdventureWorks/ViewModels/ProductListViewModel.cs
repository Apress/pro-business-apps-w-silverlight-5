﻿using System.Collections.Generic;
using System.ComponentModel;
using AdventureWorks.Web.Models;
using AdventureWorks.Web.Services;

namespace AdventureWorks.ViewModels
{
    public class ProductListViewModel : INotifyPropertyChanged
    {
        private bool _isBusy = false;

        public IEnumerable<ProductSummary> Products { get; set; }

        public ProductListViewModel()
        {
            IsBusy = true;

            var context = new ProductSummaryContext();
            var qry = context.GetProductSummaryListQuery();
            var op = context.Load(qry);
            Products = op.Entities;

            op.Completed += op_Completed;
        }

        private void op_Completed(object sender, System.EventArgs e)
        {
            IsBusy = false;
        }

        public bool IsBusy
        {
            get { return _isBusy; }
            private set
            {
                _isBusy = value;

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("IsBusy"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
