﻿using System;
using System.Collections.ObjectModel;
using AdventureWorks.Models;

namespace AdventureWorks.ViewModels
{
    public class ErrorLogViewModel
    {
        public ObservableCollection<LogMessage> LogMessages { get; set; }

        public ErrorLogViewModel()
        {
            LogMessages = new ObservableCollection<LogMessage>();

            LogMessages.Add(new ErrorLogMessage() { Message = "Oops, something crashed!" });
            LogMessages.Add(new WarningLogMessage() { Message = "I don't like what you're doing here. Sure you really wanna do that?" });
            LogMessages.Add(new InformationLogMessage() { Message = "Yes, I'm here. Just thought I'd say hello." });
        }
    }
}
