﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ServiceModel.DomainServices.Client;
using System.Windows.Data;
using AdventureWorks.Web.Models;
using AdventureWorks.Web.Services;
using Microsoft.Windows.Data.DomainServices;

namespace AdventureWorks.ViewModels
{
    public class ProductListViewModel_DomainCollectionView : INotifyPropertyChanged
    {
        private string _searchText = "";
        private bool _isBusy = false;
        private ProductSummaryContext _context = new ProductSummaryContext();

        public IEnumerable<ProductSummary> Products { get; set; }
        public DomainCollectionView ProductCollectionView { get; set; }

        public ProductListViewModel_DomainCollectionView()
        {
            Products = new EntityList<ProductSummary>(_context.ProductSummaries);
            var collectionViewLoader = new DomainCollectionViewLoader<ProductSummary>(LoadProductSummaryList, OnLoadProductSummaryListCompleted);
            ProductCollectionView = new DomainCollectionView<ProductSummary>(collectionViewLoader, Products);

            // Configures sorting
            SortDescription sortBy = new SortDescription("Name", ListSortDirection.Ascending);
            ProductCollectionView.SortDescriptions.Add(sortBy);

            // Configures grouping
            PropertyGroupDescription groupBy = new PropertyGroupDescription("Model");
            ProductCollectionView.GroupDescriptions.Add(groupBy);

            using (ProductCollectionView.DeferRefresh())
            {
                ProductCollectionView.PageSize = 30;
                ProductCollectionView.MoveToFirstPage();
            }
        }

        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;

                using (ProductCollectionView.DeferRefresh())
                {
                    ProductCollectionView.MoveToFirstPage();
                }
            }
        }

        public bool IsBusy
        {
            get { return _isBusy; }
            private set
            {
                _isBusy = value;

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("IsBusy"));
            }
        }

        private LoadOperation<ProductSummary> LoadProductSummaryList()
        {
            IsBusy = true;

            EntityQuery<ProductSummary> query = _context.GetProductSummaryListQuery();
            query = query.Where(x => x.Name.Contains(_searchText));
            query = query.SortAndPageBy(ProductCollectionView);
            query.IncludeTotalCount = true;
            return _context.Load(query);
        }

        private void OnLoadProductSummaryListCompleted(LoadOperation<ProductSummary> op)
        {
            if (op.HasError)
            {
                // NOTE: You should add some logic for handling errors here, and mark
                //       the error as handled.
                // op.MarkErrorAsHandled();
            }
            else if (!op.IsCanceled)
            {
                ((EntityList<ProductSummary>)Products).Source = op.Entities;

                if (op.TotalEntityCount != -1)
                    ProductCollectionView.SetTotalItemCount(op.TotalEntityCount);
            }

            IsBusy = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
