﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Data;
using AdventureWorks.Web.Models;
using AdventureWorks.Web.Services;

namespace AdventureWorks.ViewModels
{
    public class ProductListViewModel_PagedCollectionView : INotifyPropertyChanged
    {
        private string _searchText = "";
        private bool _isBusy = false;

        public IEnumerable<ProductSummary> Products { get; set; }
        public PagedCollectionView ProductCollectionView { get; set; }

        public ProductListViewModel_PagedCollectionView()
        {
            IsBusy = true;

            var context = new ProductSummaryContext();
            var qry = context.GetProductSummaryListQuery();
            var op = context.Load(qry);
            Products = op.Entities;

            op.Completed += op_Completed;

            ProductCollectionView = new PagedCollectionView(Products);

            // Configures filtering
            ProductCollectionView.Filter = item =>
                ((ProductSummary)item).Name.IndexOf(SearchText, StringComparison.InvariantCultureIgnoreCase) != -1;

            // Configures sorting
            SortDescription sortBy = new SortDescription("Name", ListSortDirection.Ascending);
            ProductCollectionView.SortDescriptions.Add(sortBy);

            // Configures grouping
            PropertyGroupDescription groupBy = new PropertyGroupDescription("Model");
            ProductCollectionView.GroupDescriptions.Add(groupBy);
        }

        private void op_Completed(object sender, EventArgs e)
        {
            IsBusy = false;
        }

        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;
                ProductCollectionView.Refresh();
            }
        }

        public bool IsBusy
        {
            get { return _isBusy; }
            private set
            {
                _isBusy = value;

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("IsBusy"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
