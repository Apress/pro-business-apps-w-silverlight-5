CHAPTER 6 SAMPLE CODE
---------------------

This solution accompanies Chapter 6 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Configuring a DataGrid Control for Displaying a Summary List
- Configuring a ListBox Control for Displaying a Summary List
- Creating and Binding to the View Model Class
- Using the CollectionViewSource Class
- Wrapping Data in a PagedCollectionView
- Obtaining Data via a DomainCollectionView
- Filtering the Summary List
- Sorting the Summary List
- Grouping the Summary List
- Paging the Summary List

Note that the ImageTools assemblies in the Libs folder are used to convert GIF 
images from the server to PNGs on the fly. The GifConverter class in the Helpers
folder is used to handle this conversion.

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.