CHAPTER 14 SAMPLE CODE
----------------------

This solution accompanies Chapter 14 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Getting Started with MEF
- Specifying a Contract
- Importing Multiple Parts
- Configuring Catalogs and Downloading Modules

Note that some of the code for the first two workshops has been modified in the following 
workshops, so the code here is effectively the result of all the workshops being
implemented in turn.