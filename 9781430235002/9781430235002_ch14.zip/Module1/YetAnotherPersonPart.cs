﻿using System.ComponentModel.Composition;
using Chapter14Sample;

namespace Module1
{
    [Export(typeof(IPersonPart))]
    public class YetAnotherPersonPart : IPersonPart
    {
        public string Name { get; set; }

        public YetAnotherPersonPart()
        {
            Name = "Bart Simpson";
        }
    }
}