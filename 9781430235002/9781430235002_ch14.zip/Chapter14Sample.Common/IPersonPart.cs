﻿namespace Chapter14Sample
{
    public interface IPersonPart
    {
        string Name { get; set; }
    }
}
