﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Windows.Controls;

namespace Chapter14Sample
{
    public partial class MainPage : UserControl
    {
        [ImportMany(AllowRecomposition = true)]
        public ObservableCollection<IPersonPart> MyImportedPersonParts { get; set; }

        public MainPage()
        {
            InitializeComponent();
            
            var aggregateCatalog = new AggregateCatalog();

            var catalog1 = new DeploymentCatalog();
            aggregateCatalog.Catalogs.Add(catalog1);

            var catalog2 = new DeploymentCatalog(new Uri("Module1.xap", UriKind.Relative));
            catalog2.DownloadAsync();
            aggregateCatalog.Catalogs.Add(catalog2);

            CompositionHost.Initialize(aggregateCatalog);
            CompositionInitializer.SatisfyImports(this);

            var list = new ListBox();
            list.ItemsSource = MyImportedPersonParts;
            list.DisplayMemberPath = "Name";
            LayoutRoot.Children.Add(list);
        }
    }
}
