﻿using System.ComponentModel.Composition;

namespace Chapter14Sample
{
    [Export(typeof(IPersonPart))]
    public class PersonPart : IPersonPart
    {
        public string Name { get; set; }

        public PersonPart()
        {
            Name = "Homer Simpson";
        }
    }
}
