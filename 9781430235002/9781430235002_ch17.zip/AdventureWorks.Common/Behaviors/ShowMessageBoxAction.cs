﻿using System.Windows;
using System.Windows.Interactivity;

namespace AdventureWorks.Behaviors
{
    public class ShowMessageBoxAction : TriggerAction<UIElement>
    {
        protected override void Invoke(object parameter)
        {
            MessageBox.Show(Message, Caption, MessageBoxButton.OK);
        }

        public string Message
        {
            get { return (string)GetValue(MessageProperty); }
            set { SetValue(MessageProperty, value); }
        }

        public static readonly DependencyProperty MessageProperty =
            DependencyProperty.Register("Message", typeof(string), typeof(ShowMessageBoxAction), null);


        public string Caption
        {
            get { return (string)GetValue(CaptionProperty); }
            set { SetValue(CaptionProperty, value); }
        }

        public static readonly DependencyProperty CaptionProperty =
            DependencyProperty.Register("Caption", typeof(string), typeof(ShowMessageBoxAction), null);
    }
}
