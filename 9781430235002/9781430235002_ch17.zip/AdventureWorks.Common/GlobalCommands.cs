﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace AdventureWorks.Common
{
    //public class GlobalCommands : INotifyPropertyChanged
    //{
    //    private static GlobalCommands _instance = null;
    //    private ICommand _showLoginWindow = null;

    //    public GlobalCommands Instance
    //    {
    //        get
    //        {
    //            if (_instance == null)
    //                _instance = new GlobalCommands();

    //            return _instance;
    //        }
    //    }

    //    public ICommand ShowLoginWindow
    //    {
    //        get { return _showLoginWindow; }
    //        set
    //        {
    //            _showLoginWindow = value;

    //            if (PropertyChanged != null)
    //                PropertyChanged(this, new PropertyChangedEventArgs("ShowLoginWindow"));
    //        }
    //    }

    //    public event PropertyChangedEventHandler PropertyChanged;
    //}

    public static class GlobalCommands
    {
        public static ICommand ShowLoginWindow = null;
    }
}
