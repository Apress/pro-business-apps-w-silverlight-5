﻿
namespace AdventureWorks.Web
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Data.Objects.DataClasses;
    using System.Linq;
    using System.ServiceModel.DomainServices.Hosting;
    using System.ServiceModel.DomainServices.Server;
    using AdventureWorks.ProductionModule.MiddleTier.Web;


    // The MetadataTypeAttribute identifies ProductCategoryMetadata as the class
    // that carries additional metadata for the ProductCategory class.
    [MetadataTypeAttribute(typeof(ProductCategory.ProductCategoryMetadata))]
    public partial class ProductCategory
    {

        // This class allows you to attach custom attributes to properties
        // of the ProductCategory class.
        //
        // For example, the following marks the Xyz property as a
        // required property and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz { get; set; }
        internal sealed class ProductCategoryMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private ProductCategoryMetadata()
            {
            }

            public DateTime ModifiedDate { get; set; }

            public string Name { get; set; }

            public int ProductCategoryID { get; set; }

            public EntityCollection<ProductSubcategory> ProductSubcategories { get; set; }

            public Guid rowguid { get; set; }
        }
    }

    // The MetadataTypeAttribute identifies ProductModelMetadata as the class
    // that carries additional metadata for the ProductModel class.
    [MetadataTypeAttribute(typeof(ProductModel.ProductModelMetadata))]
    public partial class ProductModel
    {

        // This class allows you to attach custom attributes to properties
        // of the ProductModel class.
        //
        // For example, the following marks the Xyz property as a
        // required property and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz { get; set; }
        internal sealed class ProductModelMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private ProductModelMetadata()
            {
            }

            public string CatalogDescription { get; set; }

            public string Instructions { get; set; }

            public DateTime ModifiedDate { get; set; }

            public string Name { get; set; }

            public int ProductModelID { get; set; }

            public EntityCollection<ProductModelIllustration> ProductModelIllustrations { get; set; }

            public EntityCollection<ProductModelProductDescriptionCulture> ProductModelProductDescriptionCultures { get; set; }

            public EntityCollection<Product> Products { get; set; }

            public Guid rowguid { get; set; }
        }
    }

    // The MetadataTypeAttribute identifies ProductSubcategoryMetadata as the class
    // that carries additional metadata for the ProductSubcategory class.
    [MetadataTypeAttribute(typeof(ProductSubcategory.ProductSubcategoryMetadata))]
    public partial class ProductSubcategory
    {

        // This class allows you to attach custom attributes to properties
        // of the ProductSubcategory class.
        //
        // For example, the following marks the Xyz property as a
        // required property and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz { get; set; }
        internal sealed class ProductSubcategoryMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private ProductSubcategoryMetadata()
            {
            }

            public DateTime ModifiedDate { get; set; }

            public string Name { get; set; }

            public ProductCategory ProductCategory { get; set; }

            public int ProductCategoryID { get; set; }

            public EntityCollection<Product> Products { get; set; }

            public int ProductSubcategoryID { get; set; }

            public Guid rowguid { get; set; }
        }
    }

    // The MetadataTypeAttribute identifies UnitMeasureMetadata as the class
    // that carries additional metadata for the UnitMeasure class.
    [MetadataTypeAttribute(typeof(UnitMeasure.UnitMeasureMetadata))]
    public partial class UnitMeasure
    {

        // This class allows you to attach custom attributes to properties
        // of the UnitMeasure class.
        //
        // For example, the following marks the Xyz property as a
        // required property and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz { get; set; }
        internal sealed class UnitMeasureMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private UnitMeasureMetadata()
            {
            }

            public DateTime ModifiedDate { get; set; }

            public string Name { get; set; }

            public EntityCollection<Product> Products { get; set; }

            public EntityCollection<Product> Products1 { get; set; }

            public string UnitMeasureCode { get; set; }
        }
    }
}
