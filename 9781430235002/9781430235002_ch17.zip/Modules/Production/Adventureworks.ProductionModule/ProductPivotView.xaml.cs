﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using AdventureWorks.Web.Models;
using MEFModuleLoader.Attributes;

namespace AdventureWorks.Views
{
    [ExportModulePage(NavigateUri = "ProductPivotView")]
    public partial class ProductPivotView : Page
    {
        public ProductPivotView()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void ItemAdornerButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            ProductSummary product = button.DataContext as ProductSummary;

            MessageBox.Show("Item adorner clicked for the " + product.Name + " product!", "AdventureWorks", MessageBoxButton.OK);
        }
    }
}
