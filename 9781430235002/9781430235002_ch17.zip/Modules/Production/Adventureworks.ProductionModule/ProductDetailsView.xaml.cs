﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using System.Windows.Printing;
using AdventureWorks.ViewModels;
using MEFModuleLoader.Attributes;

namespace AdventureWorks.Views
{
    [ExportModulePage(NavigateUri = "ProductDetailsView")]
    public partial class ProductDetailsView : Page
    {
        public ProductDetailsView()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(ProductDetailsView_Loaded);
        }

        private void ProductDetailsView_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = new ProductDetailsViewModel(ParamID);
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            
        }

        private int ParamID
        {
            get
            {
                int paramValue = 0;
                const string paramName = "ID";

                if (NavigationContext.QueryString.ContainsKey(paramName))
                    int.TryParse(NavigationContext.QueryString[paramName], out paramValue);

                return paramValue;
            }
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += Document_PrintPage;
            pd.Print("Chapter 15 - Printing Workshop");
        }

        private void Document_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Workshop: Printing a Screen
            // Note that only part of the screen is likely to be printed because
            // we haven't constrained the width of the view to fit on the page.
            e.PageVisual = this;
            e.HasMorePages = false;
        }
    }
}
