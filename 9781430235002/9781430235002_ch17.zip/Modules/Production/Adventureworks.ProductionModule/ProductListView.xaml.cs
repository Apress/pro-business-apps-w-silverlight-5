﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Printing;
using System.Windows.Shapes;
using AdventureWorks.ViewModels;
using AdventureWorks.Web.Models;
using MEFModuleLoader.Attributes;

namespace AdventureWorks.Views
{
    [ExportModulePage(NavigateUri = "ProductListView")]
    public partial class ProductListView : Page
    {
        private const int rowsPerPage = 65;
        private List<ProductSummary> _productCollection = null;

        public ProductListView()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += Document_PrintPage;
            pd.Print("Chapter 15 - Printing Workshop");
        }

        private void Document_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Create a collection of items to print. In real-life projects, you'd
            // probably skip this step and work with the collection view directly,
            // but we'll do this so the rest of the code matches what's in the book.
            var vm = this.DataContext as ProductListViewModel;
            _productCollection = new List<ProductSummary>();

            foreach (ProductSummary product in vm.ProductCollectionView)
            {
                _productCollection.Add(product);
            }

            // Now print the contents of the collection
            PrintDocument pd = sender as PrintDocument;
            e.PageVisual = GenerateReportPage(pd.PrintedPageCount, e);
            e.HasMorePages = ((pd.PrintedPageCount + 1) * rowsPerPage < _productCollection.Count);
        }

        private UIElement GenerateReportPage(int pageNumber, PrintPageEventArgs printPage)
        {
            Grid pageLayoutGrid = CreatePageLayout(printPage);

            int startIndex = pageNumber * rowsPerPage;

            for (int rowIndex = 0; rowIndex < rowsPerPage; rowIndex++)
            {
                if (startIndex + rowIndex < _productCollection.Count)
                {
                    // Create the row
                    RowDefinition row = new RowDefinition();
                    row.Height = new GridLength(1, GridUnitType.Auto);
                    pageLayoutGrid.RowDefinitions.Add(row);

                    // Populate it with data from the current item in the collection
                    ProductSummary product = _productCollection[startIndex + rowIndex];
                    AddGridCell(pageLayoutGrid, rowIndex + 1, 0, product.Name);
                    AddGridCell(pageLayoutGrid, rowIndex + 1, 1, product.Number);
                    AddGridCell(pageLayoutGrid, rowIndex + 1, 2, product.QuantityAvailable.ToString());
                    AddGridCell(pageLayoutGrid, rowIndex + 1, 3, product.ListPrice.ToString("C"));
                    AddGridCell(pageLayoutGrid, rowIndex + 1, 4, product.Model);
                }
            }

            return pageLayoutGrid;
        }

        private Grid CreatePageLayout(PrintPageEventArgs printPage)
        {
            Grid pageLayoutGrid = new Grid();
            pageLayoutGrid.MaxWidth = printPage.PrintableArea.Width;

            // Create the columns
            for (int colIndex = 0; colIndex < 5; colIndex++)
            {
                var column = new ColumnDefinition();
                column.Width = new GridLength(1, GridUnitType.Auto);
                pageLayoutGrid.ColumnDefinitions.Add(column);
            }

            // Create the header row
            RowDefinition headerRow = new RowDefinition();
            headerRow.Height = new GridLength(1, GridUnitType.Auto);
            pageLayoutGrid.RowDefinitions.Add(headerRow);

            AddGridCell(pageLayoutGrid, 0, 0, "Name", true);
            AddGridCell(pageLayoutGrid, 0, 1, "Number", true);
            AddGridCell(pageLayoutGrid, 0, 2, "Quantity Available", true);
            AddGridCell(pageLayoutGrid, 0, 3, "List Price", true);
            AddGridCell(pageLayoutGrid, 0, 4, "Model", true);

            // Show a line underneath the header
            Line line = new Line();
            line.Stretch = Stretch.Fill;
            line.VerticalAlignment = VerticalAlignment.Bottom;
            line.Stroke = new SolidColorBrush(Colors.Black);
            line.X2 = pageLayoutGrid.MaxWidth;
            line.SetValue(Grid.RowProperty, 0);
            line.SetValue(Grid.ColumnProperty, 0);
            line.SetValue(Grid.ColumnSpanProperty, 5);
            pageLayoutGrid.Children.Add(line);

            return pageLayoutGrid;
        }

        private void AddGridCell(Grid pageLayoutGrid, int row, int col,
                                 string text, bool isBold = false)
        {
            TextBlock cellText = new TextBlock();
            cellText.Text = text;
            cellText.Margin = new Thickness(3, 0, 3, 0);

            if (isBold)
                cellText.FontWeight = FontWeights.Bold;

            cellText.SetValue(Grid.RowProperty, row);
            cellText.SetValue(Grid.ColumnProperty, col);

            pageLayoutGrid.Children.Add(cellText);
        }
    }
}
