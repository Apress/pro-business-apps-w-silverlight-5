﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.ServiceModel.DomainServices.Client;
using System.Windows.Input;
using AdventureWorks.ProductionModule.MiddleTier.Web;
using AdventureWorks.Web.Services;
using SimpleMVVM;

namespace AdventureWorks.ViewModels
{
    public class ProductDetailsViewModel : ViewModelBase
    {
        private ProductContext _context = new ProductContext();
        private DictionaryContext _dictionaryContext = new DictionaryContext();
        private Product _product = null;
        private int _productCategoryID = 0;

        public ProductDetailsViewModel(int productID)
        {
            if (productID != 0)
            {
                IsBusy = true;

                // Load the product details from the server
                var qry = _context.GetProductQuery(productID);
                var op = _context.Load(qry);

                op.Completed += op_Completed;
            }
            else
            {
                // This is a new product, so create a new Product object and add it to the context
                _product = new Product();

                // Set some default values
                _product.SellStartDate = DateTime.Today;
                _product.SafetyStockLevel = 100;
                _product.ReorderPoint = 10;

                // Add it to the collection of products managed by the context
                _context.Products.Add(_product);
            }

            LoadUnitMeasureList();
            LoadModelList();
            LoadCategoryList();

            SubcategoryList = new ObservableCollection<ProductSubcategory>();
        }

        public Product Product
        {
            get { return _product; }
            private set
            {
                SetPropertyValue(ref _product, value, () => Product);
            }
        }

        public IEnumerable<UnitMeasure> UnitMeasureList { get; private set; }
        public IEnumerable<ProductModel> ModelList { get; private set; }
        public IEnumerable<ProductCategory> CategoryList { get; private set; }
        public ObservableCollection<ProductSubcategory> SubcategoryList { get; private set; }

        // Since there's no ProductCategoryID property on the Product entity
        // we'll put a proxy property here for it
        public int ProductCategoryID
        {
            get
            {
                return _productCategoryID;
            }
            set
            {
                SetPropertyValue(ref _productCategoryID, value, () => ProductCategoryID);

                // Load the list of subcategories for this category
                LoadSubcategoryList();
            }
        }

        private void op_Completed(object sender, System.EventArgs e)
        {
            IsBusy = false;

            LoadOperation op = sender as LoadOperation;

            if (op.HasError)
            {
                // An event is raised indicating an error has occurred. The view can
                // then listen for this and show a message box in response.
                OnNotifyError("An error occurred loading the product:" + op.Error.Message);

                // So the error doesn't get thrown
                op.MarkErrorAsHandled();
            }
            else
            {
                Product = op.Entities.FirstOrDefault() as Product;

                int productCategoryID = 0;

                if (Product != null && Product.ProductSubcategory != null)
                    productCategoryID = _product.ProductSubcategory.ProductCategoryID;

                ProductCategoryID = productCategoryID;
            }

            // Refresh the delete command's can execute state
            DeleteProductCommand.CanExecute(null);
        }

        public ICommand SubmitChangesCommand
        {
            get
            {
                return new DelegateCommand(SubmitChanges, (param) => true);
            }
        }

        public void SubmitChanges(object param)
        {
            IsBusy = true;

            SubmitOperation op = _context.SubmitChanges();
            op.Completed += Submit_Completed;
        }

        private void Submit_Completed(object sender, System.EventArgs e)
        {
            SubmitOperation op = sender as SubmitOperation;

            if (op.HasError)
            {
                DomainOperationException error = op.Error as DomainOperationException;
                string errorText = "An error occurred saving the product:" + op.Error.Message;

                switch (error.Status)
                {
                    case OperationErrorStatus.Conflicts:
                        // Handle concurrency violations

                        // Loop through the entities with concurrency violations
                        foreach (Product product in op.EntitiesInError)
                        {
                            EntityConflict conflictinfo = product.EntityConflict;
                            Product currentProduct = conflictinfo.CurrentEntity as Product;
                            Product originalProduct = conflictinfo.OriginalEntity as Product;
                            Product storeProduct = conflictinfo.StoreEntity as Product;

                            // Handle any conflicts automatically (if you wish)
                            // You can get the names of the properties whose value has changed
                            // from the conflictinfo.PropertyNames property

                            // Force the user's version to overwrite the server’s version
                            //product.EntityConflict.Resolve();
                        }

                        errorText = "Another user has modified the details of this product since you loaded it. To avoid overwriting their changes, you will need to reload the product and make your changes again.";

                        break;
                    case OperationErrorStatus.ServerError:
                        // Handle server errors
                        break;
                    case OperationErrorStatus.Unauthorized:
                        // Handle unauthorized domain operation access
                        errorText = "You do not have permission to save product details.";
                        break;
                    case OperationErrorStatus.ValidationFailed:
                        // Handle validation rule failures
                        errorText = "You have one or more validation errors that must be resolved before saving the product.";
                        break;
                    default:
                        // Handle other possible statuses
                        break;
                }

                // An event is raised indicating an error has occurred. The view can
                // then listen for this and show a message box in response.
                OnNotifyError(errorText);

                // So the error doesn't get thrown
                op.MarkErrorAsHandled();
            }

            IsBusy = false;

            // Refresh the delete command's can execute state
            DeleteProductCommand.CanExecute(null);
        }

        private ICommand _deleteProductCommand = null; // Reference to command needs to be maintained, or otherwise the UI doesn't keep listening to its CanExecuteChanged event
        public ICommand DeleteProductCommand
        {
            get
            {
                if (_deleteProductCommand == null)
                    _deleteProductCommand = new DelegateCommand(DeleteProduct, (param) => Product != null && Product.ProductID != 0);

                return _deleteProductCommand;
            }
        }

        public void DeleteProduct(object param)
        {
            IsBusy = true;

            // NOTE: This operation will fail when used with the AdventureWorks database.
            // The AdventureWorks database needs you to delete related data before you can delete the product.
            // Included here just for reference.
            _context.Products.Remove(Product);
            SubmitOperation op = _context.SubmitChanges();
            op.Completed += Submit_Completed;
        }

        private void LoadUnitMeasureList()
        {
            LoadOperation<UnitMeasure> op = _dictionaryContext.Load(_dictionaryContext.GetUnitMeasuresQuery());
            UnitMeasureList = op.Entities;
        }

        private void LoadModelList()
        {
            LoadOperation<ProductModel> op = _dictionaryContext.Load(_dictionaryContext.GetProductModelsQuery());
            ModelList = op.Entities;
        }

        private void LoadCategoryList()
        {
            LoadOperation<ProductCategory> op = _dictionaryContext.Load(_dictionaryContext.GetProductCategoriesQuery());
            CategoryList = op.Entities;
            op.Completed += LoadCategoryList_Completed;
        }

        private void LoadCategoryList_Completed(object sender, System.EventArgs e)
        {
            LoadOperation op = sender as LoadOperation;

            if (op.HasError)
            {
                op.MarkErrorAsHandled(); // Ignore error for now
            }
            else
            {
                OnPropertyChanged("ProductCategoryID");
            }
        }

        private void LoadSubcategoryList()
        {
            LoadOperation<ProductSubcategory> op = _dictionaryContext.Load(_dictionaryContext.GetProductSubcategoriesQuery(ProductCategoryID));
            op.Completed += LoadSubcategoryList_Completed;
        }

        private void LoadSubcategoryList_Completed(object sender, System.EventArgs e)
        {
            var op = sender as LoadOperation<ProductSubcategory>;

            if (op.HasError)
            {
                op.MarkErrorAsHandled(); // Ignore error for now
            }
            else
            {
                SubcategoryList.Clear();

                foreach (ProductSubcategory subcategory in op.Entities)
                    SubcategoryList.Add(subcategory);
            }
        }
    }
}
