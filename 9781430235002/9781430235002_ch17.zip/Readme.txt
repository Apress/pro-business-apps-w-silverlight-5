CHAPTER 17 SAMPLE CODE
----------------------

This solution accompanies Chapter 17 of Pro Business Applications with Silverlight 5.
This sample includes code for the following workshops in the chapter:

- Creating the Application Preloader Files
- Designing the Application Preloader�s Appearance
- Updating the Application Download Progress
- Configuring the Preloader in the HTML File
- Modularizing Your Application
- Communication Between the Shell Application and the Modules (the Contacts module has a button that asks the shell to show the login window)

Note that the preloader has been disabled. As mentioned in the book, often it will interfere
with the debugging process.  You can enable it by opening the AdventureWorksTestPage.html page
and uncommenting the lines indicated there by a comment.

The code for the MEFModuleLoader.dll assembly is also available with this sample, but has not 
been included in this solution.

Note how the Production module has been configured to use RIA class libraries to enable it
to just have code generated for the domain services and entities it needs.

The security configured in chapter 8 has been disabled so that it doesn't interfere with you 
playing with the samples.

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.
      PLEASE NOTE that there are now additional connections strings which need to be
      configured.