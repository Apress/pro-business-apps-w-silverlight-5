using System;
using System.Collections.Generic;
using Microsoft.Reporting.WebForms;
using SilverlightLOBFramework.Reports;
using System.Web;

namespace AdventureWorks.Web.Reports
{
    public class ProductCatalogReportRenderer : BaseReportRenderer
    {
        public override string ReportPath
        {
            get { return @"Reports\Product Catalog.rdlc"; }
        }

        public override string ReportName
        {
            get { return "Product Catalog"; }
        }

        public override void PopulateReportDataSources(ReportDataSourceCollection dataSources)
        {
            List<ProductCatalogReportData> productCatalogReportData = ProductCatalogReportData.GetCatalogProductReportData();
            dataSources.Add(new ReportDataSource("ProductCatalog", productCatalogReportData));
        }

        //public override bool IsUserAccessAuthorised
        //{
        //    get
        //    {
        //        bool isAuthorised = HttpContext.Current.User.IsInRole("Managers");
        //        return isAuthorised;
        //    }
        //}
    }
}