﻿using System;
using System.Collections.Generic;
using AdventureWorks.Web.Reports;
using SilverlightLOBFramework.Reports;

namespace AdventureWorks.Web
{
    public class Report : BaseReportHandler
    {
        protected override void RegisterRenderers(Dictionary<string, Type> reportRenderers)
        {
            reportRenderers.Add("ProductCatalog", typeof(ProductCatalogReportRenderer));
            reportRenderers.Add("ProductDetails", typeof(ProductDetailsReportRenderer));
        }
    }
}