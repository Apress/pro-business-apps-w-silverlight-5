﻿using System.Collections.Generic;

namespace MEFModuleLoader.Navigation
{
    public class NavigationContext
    {
        private static NavigationContext instance;

        public static NavigationContext Instance
        {
            get
            {
                if (instance == null)
                    instance = new NavigationContext();

                return instance;
            }
        }

        private NavigationContext()
        {
            queryString = new Dictionary<string, string>();
        }

        private Dictionary<string, string> queryString;

        public Dictionary<string, string> QueryString
        {
            get { return queryString; }
            set { queryString = value; }
        }
    }
}
