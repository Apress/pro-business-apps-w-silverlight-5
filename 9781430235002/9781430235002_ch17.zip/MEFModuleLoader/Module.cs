﻿using System.ComponentModel;

namespace MEFModuleLoader
{
    public class Module : INotifyPropertyChanged
    {
        #region Properties

        private string m_Package;
        public string Package
        {
            get
            {
                return this.m_Package;
            }
            set
            {
                this.m_Package = value;

                RaisePropertyChanged("Package");
            }
        }

        private string m_Title;
        public string Title
        {
            get
            {
                return this.m_Title;
            }
            set
            {
                this.m_Title = value;

                RaisePropertyChanged("Title");
            }
        }

        private string m_Uri;
        public string Uri
        {
            get
            {
                return this.m_Uri;
            }
            set
            {
                this.m_Uri = value;

                RaisePropertyChanged("Uri");
            }
        }  
        #endregion

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propName)
        {
            var handler = this.PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propName));
            }
        }

        #endregion
    }
}
