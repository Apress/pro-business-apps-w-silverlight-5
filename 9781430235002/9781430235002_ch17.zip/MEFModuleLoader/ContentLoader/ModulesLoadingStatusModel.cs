﻿using System.ComponentModel;
using MEFModuleLoader.Deployment;
using MEFModuleLoader.Interfaces;

namespace MEFModuleLoader.ContentLoader
{
    public class ModulesLoadingStatusModel : INotifyPropertyChanged
    {
        private bool isBusy = false;

        public ModulesLoadingStatusModel()
        {
            ModulesLoader.Instance.ModulesAvailable += new ModulesAvailableHandler(Instance_ModulesAvailable);
            ModulesLoader.Instance.ModulesLoading += new ModulesLoadingHandler(Instance_ModulesLoading);
        }
        
        private void Instance_ModulesLoading(Module module)
        {
            IsBusy = true;
        }

        private void Instance_ModulesAvailable(System.Lazy<System.Windows.Controls.Page, IModuleMetadata>[] modules)
        {
            IsBusy = false;
        }

        public bool IsBusy
        {
            get { return isBusy; }
            set
            {
                if (isBusy != value)
                {
                    isBusy = value;

                    if (PropertyChanged != null)
                        PropertyChanged(this, new PropertyChangedEventArgs("IsBusy"));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
