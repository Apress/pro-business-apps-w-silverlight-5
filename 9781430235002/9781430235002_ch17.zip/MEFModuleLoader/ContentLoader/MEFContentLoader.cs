﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Windows;
using System.Windows.Controls;
using MEFModuleLoader.Interfaces;

namespace MEFModuleLoader.ContentLoader
{
    /// <summary>
    /// ContentLoader that uses MEF to locate Pages for the given Uris.
    /// </summary>
    /// <seealso cref="ContentLoaderBase"/>
    public class MEFContentLoader : ContentLoaderBase
    {
        public MEFContentLoader()
        {

        }

        protected override LoaderBase CreateLoader()
        {
            return new MEFLoader(this);
        }

        /// <summary>
        /// Gets or sets the CompositionContainer to use when loading.  If Container is null,
        /// CompositionInitializer will be used.
        /// </summary>
        public CompositionContainer Container
        {
            get { return (CompositionContainer)GetValue(ContainerProperty); }
            set { SetValue(ContainerProperty, value); }
        }

        /// <summary>
        /// Gets or sets the CompositionContainer to use when loading.  If Container is null,
        /// CompositionInitializer will be used.
        /// </summary>
        public static readonly DependencyProperty ContainerProperty =
            DependencyProperty.Register("Container", typeof(CompositionContainer), typeof(MEFContentLoader), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the ExportFactories that are used to fulfill requests to load.
        /// </summary>
        [ImportMany(AllowRecomposition = true)]
        public IEnumerable<ExportFactory<Page, IModuleMetadata>> PageFactories
        {
            get;
            set;
        }

        private bool initialized;

        public bool Initialized
        {
            get { return initialized; }
        }

        public void Initialize()
        {
            if (Container == null)
                CompositionInitializer.SatisfyImports(this);
            else
                Container.ComposeParts(this);
            initialized = true;
        }
    }
}
