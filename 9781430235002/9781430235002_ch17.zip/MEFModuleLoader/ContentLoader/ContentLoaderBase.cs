﻿using System;
using System.Windows;
using System.Windows.Navigation;

namespace MEFModuleLoader.ContentLoader
{
    /// <summary>
    /// Base class to loading modules on demand.
    /// </summary>
    public abstract class ContentLoaderBase : DependencyObject, INavigationContentLoader
    {
        private PageResourceContentLoader _standardPageLoader = new PageResourceContentLoader();

        #region Construction / Destruction
        protected ContentLoaderBase()
        {

        }
        #endregion 

        #region Methods
        /// <summary>
        /// Creates an instance of a LoaderBase that will be used to handle loading.
        /// </summary>
        /// <returns>An instance of a LoaderBase.</returns>
        protected abstract LoaderBase CreateLoader();

        /// <summary>
        /// Creates an instance of a LoaderBase that will be used to handle loading by calling CreateLoader method.
        /// </summary>
        /// <returns>An instance of a LoaderBase.</returns>
        private LoaderBase CreateLoaderPrivate()
        {
            LoaderBase loader = CreateLoader();
            loader.ContentLoader = this;
            return loader;
        }

        /// <summary>
        /// Build the page to display
        /// </summary>
        /// <param name="result"></param>
        internal void Complete(IAsyncResult result)
        {
            lock (((ContentLoaderBaseAsyncResult)result).Lock)
            {
                if (Dispatcher.CheckAccess())
                {
                    ((ContentLoaderBaseAsyncResult)result).Callback(result);
                }
                else
                {
                    Dispatcher.BeginInvoke(() => ((ContentLoaderBaseAsyncResult)result).Callback(result));
                }
            }
        }
        #endregion       

        #region INavigationContentLoader Members

        /// <summary>
        /// Begins asynchronous loading of the content for the specified target URI.
        /// </summary>
        /// <param name="targetUri">The URI to load content for.</param>
        /// <param name="currentUri">The URI that is currently loaded.</param>
        /// <param name="userCallback">The method to call when the content finishes loading.</param>
        /// <param name="asyncState">An object for storing custom state information.</param>
        /// <returns>An object that stores information about the asynchronous operation.</returns>
        public IAsyncResult BeginLoad(Uri targetUri, Uri currentUri, AsyncCallback userCallback, object asyncState)
        {
            // Determine whether this is a URI that needs to be retrieved from another XAP
            // via MEF.  If not, simply delegate to the standard page content loader.
            if (targetUri.ToString().ToLower().Contains(".xap;"))
            {
                // Load page from a separate package
                LoaderBase loader = CreateLoaderPrivate();

                ContentLoaderBaseAsyncResult result = new ContentLoaderBaseAsyncResult(asyncState, loader, userCallback);
                result.BeginLoadCompleted = false;
                loader.Result = result;
                lock (result.Lock)
                {
                    loader.Load(targetUri, currentUri);
                    result.BeginLoadCompleted = true;
                    return result;
                }
            }
            else
            {
                // Delegate to the standard page content loader
                return _standardPageLoader.BeginLoad(targetUri, currentUri, userCallback, asyncState);
            }
        }


        /// <summary>
        /// Gets a value that indicates whether the specified URI can be loaded.
        /// </summary>
        /// <param name="targetUri">The URI to test.</param>
        /// <param name="currentUri">The URI that is currently loaded.</param>
        /// <returns>true if the URI can be loaded; otherwise, false.</returns>
        public virtual bool CanLoad(Uri targetUri, Uri currentUri)
        {
            return true;
        }

        /// <summary>
        /// Attempts to cancel content loading for the specified asynchronous operation.
        /// </summary>
        /// <param name="asyncResult">An object that identifies the asynchronous operation to cancel.</param>
        public void CancelLoad(IAsyncResult asyncResult)
        {
            ((ContentLoaderBaseAsyncResult)asyncResult).Loader.CancelInternal();
        }

        /// <summary>
        /// Completes the asynchronous content loading operation.
        /// </summary>
        /// <param name="asyncResult">An object that identifies the asynchronous operation.</param>
        /// <returns>An object that represents the result of the asynchronous content loading operation.</returns>
        public LoadResult EndLoad(IAsyncResult asyncResult)
        {
            if (asyncResult is ContentLoaderBaseAsyncResult)
            {
                var result = (ContentLoaderBaseAsyncResult)asyncResult;
                if (result.Error != null)
                {
                    throw result.Error;
                }
                if (result.Page != null)
                {
                    return new LoadResult(result.Page);
                }
                return new LoadResult(result.RedirectUri);
            }
            else
            {
                return _standardPageLoader.EndLoad(asyncResult);
            }
        }
        #endregion
    }
}
