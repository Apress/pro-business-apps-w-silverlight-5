﻿using System;
using System.ComponentModel.Composition;
using System.Windows.Controls;
using MEFModuleLoader.Interfaces;

namespace MEFModuleLoader.Deployment
{
    /// <summary>
    /// Load modules and add them in DeploymentCatalogService
    /// </summary>
    public class ModulesLoader: IModulesLoader, IPartImportsSatisfiedNotification
    {
        #region Events

        /// <summary>
        /// Event raise the download is completed
        /// </summary>
        public event ModulesAvailableHandler ModulesAvailable;

        /// <summary>
        /// Event raise when the download begin
        /// </summary>
        public event ModulesLoadingHandler ModulesLoading;

        #endregion

        #region Public Contructor

        private ModulesLoader()
        {
            if (!DeploymentCatalogService.Instance.IsInitialized)
            {
                DeploymentCatalogService.Instance.Initialize();
            }
            CompositionInitializer.SatisfyImports(this);
        }

        #endregion

        #region Properties
        private static ModulesLoader instance;

        public static ModulesLoader Instance
        {
            get
            {
                if (instance == null)
                    instance = new ModulesLoader();

                return instance;
            }
        }

        /// <summary>
        /// Collection on dowloaded modules
        /// </summary>
        [ImportMany(AllowRecomposition = true)]
        public Lazy<Page, IModuleMetadata>[] Modules { get; set; }

        #endregion

        #region IPartImportsSatisfiedNotification Members
        /// <summary>
        /// Raise the ModulesAvailable event
        /// </summary>
        public void OnImportsSatisfied()
        {
            var handler = this.ModulesAvailable;
            if (handler != null)
            {
                handler(this.Modules);
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Raise the ModulesLoading event
        /// </summary>
        /// <param name="module"></param>
        public void OnModuleLoading(Module module)
        {
            var handler = this.ModulesLoading;
            if (handler != null)
            {
                handler(module);
            }
        }

        /// <summary>
        /// Load a module
        /// </summary>
        /// <param name="module"></param>
        public void LoadModule(Module module)
        {
            OnModuleLoading(module);
            DeploymentCatalogService.Instance.AddXap(module.Package);
        }

        /// <summary>
        /// Load a module
        /// </summary>
        /// <param name="pageRequested">Uri of xap package</param>
        public void LoadModule(string pageRequested)
        {
            ModulesLoader.Instance.LoadModule(new Module() { Package = pageRequested });
        }

        #endregion       
    }
}
