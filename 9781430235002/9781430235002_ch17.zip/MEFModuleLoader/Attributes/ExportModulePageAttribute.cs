﻿using System;
using System.ComponentModel.Composition;
using System.Windows.Controls;
using MEFModuleLoader.Interfaces;

namespace MEFModuleLoader.Attributes
{
    /// <summary>
    /// Attribut to identify module and pages
    /// </summary>
    [MetadataAttribute]
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)] 
    public class ExportModulePageAttribute : ExportAttribute, IModuleMetadata
    {
        public ExportModulePageAttribute()
            : base(typeof(Page))
        {
        }
        
        /// <summary>
        /// Page uri
        /// </summary>
        public string NavigateUri { get; set; }       
    }
}
