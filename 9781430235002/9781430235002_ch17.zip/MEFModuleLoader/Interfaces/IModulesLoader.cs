﻿using System;
using System.Windows.Controls;

namespace MEFModuleLoader.Interfaces
{
    public delegate void ModulesAvailableHandler(Lazy<Page, IModuleMetadata>[] modules);
    public delegate void ModulesLoadingHandler(Module module);

    public interface IModulesLoader
    {
        event ModulesAvailableHandler ModulesAvailable;
        event ModulesLoadingHandler ModulesLoading;

        Lazy<Page, IModuleMetadata>[] Modules { get; set; }

        void LoadModule(Module module);
        void LoadModule(string pageRequested);
        //void OnImportsSatisfied();
    }
}
