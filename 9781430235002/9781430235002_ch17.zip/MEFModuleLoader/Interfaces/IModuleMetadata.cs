﻿namespace MEFModuleLoader.Interfaces
{
    public interface IModuleMetadata
    {
         string NavigateUri { get; }
    }
}
