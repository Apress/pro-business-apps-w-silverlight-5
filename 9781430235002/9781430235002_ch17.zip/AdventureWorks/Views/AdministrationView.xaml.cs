﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace AdventureWorks.Views
{
    public partial class AdministrationView : Page
    {
        public AdministrationView()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(AdministrationView_Loaded);
        }

        private void AdministrationView_Loaded(object sender, RoutedEventArgs e)
        {
            var user = WebContext.Current.User;

            if (!user.IsAuthenticated || !user.IsInRole("Administrators"))
                NavigationService.Navigate(new Uri("Home", UriKind.Relative));
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

    }
}
