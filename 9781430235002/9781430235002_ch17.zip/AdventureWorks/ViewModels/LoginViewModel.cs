﻿using System;
using System.ComponentModel;
using System.ServiceModel.DomainServices.Client.ApplicationServices;
using System.Windows.Input;
using SimpleMVVM;

namespace AdventureWorks.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private string _userName;
        private string _password;

        public string UserName
        {
            get { return _userName; }
            set
            {
                _userName = value;

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("UserName"));
            }
        }

        public string Password
        {
            get { return _password; }
            set
            {
                _password = value;

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Password"));
            }
        }

        public ICommand LoginCommand
        {
            get
            {
                return new DelegateCommand(BeginLogin, CanLogin);
            }
        }

        private void BeginLogin(object param)
        {
            // Logic to validate the user's login goes here.  We'll assume the
            // credentials are immediately valid (you'd normally go back to the
            // server first), and raise the LoginSuccessful event
            //if (LoginSuccessful != null)
            //    LoginSuccessful(this, new EventArgs());

            // Let's actually perform a login operation in this sample
            WebContext.Current.Authentication.Login(new LoginParameters(UserName, Password), LoginOperation_Completed, null);
        }

        private void LoginOperation_Completed(LoginOperation loginOperation)
        {
            if (loginOperation.LoginSuccess)
            {
                if (LoginSuccessful != null)
                    LoginSuccessful(this, new EventArgs());
            }
            else if (loginOperation.HasError)
            {
                if (LoginError != null)
                    LoginError(this, new ErrorEventArgs(loginOperation.Error.Message));

                loginOperation.MarkErrorAsHandled();
            }
            else
            {
                if (LoginFailed != null)
                    LoginFailed(this, new ErrorEventArgs("Invalid login!"));
            }
        }

        private bool CanLogin(object param)
        {
            return true;
        }

        public event EventHandler LoginSuccessful;
        public event EventHandler<ErrorEventArgs> LoginFailed; // Modified slightly from book version, in order to pass error message with event
        public event EventHandler<ErrorEventArgs> LoginError;  // Ditto

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
