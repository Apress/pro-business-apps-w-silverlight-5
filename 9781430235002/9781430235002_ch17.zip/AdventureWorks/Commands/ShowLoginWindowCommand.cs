﻿using System;
using System.Windows.Input;
using AdventureWorks.LoginUI;

namespace AdventureWorks.Commands
{
    public class ShowLoginWindowCommand : ICommand
    {
        public bool CanExecute(object parameter)
        {
            return !WebContext.Current.User.IsAuthenticated;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            if (CanExecute(parameter))
            {
                LoginRegistrationWindow loginWindow = new LoginRegistrationWindow();
                loginWindow.Show();
            }
        }
    }
}
