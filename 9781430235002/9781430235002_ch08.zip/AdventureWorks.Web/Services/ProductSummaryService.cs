﻿
namespace AdventureWorks.Web.Services
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Data;
    using System.Linq;
    using System.ServiceModel.DomainServices.EntityFramework;
    using System.ServiceModel.DomainServices.Hosting;
    using System.ServiceModel.DomainServices.Server;
    using AdventureWorks.Web;
    using AdventureWorks.Web.Models;

    // Implements application logic using the AdventureWorksEntities context.
    // TODO: Add your application logic to these methods or in additional methods.
    // TODO: Wire up authentication (Windows/ASP.NET Forms) and uncomment the following to disable anonymous access
    // Also consider adding roles to restrict access as appropriate.
    [EnableClientAccess()]
    [RequiresAuthentication]
    public class ProductSummaryService : LinqToEntitiesDomainService<AdventureWorksEntities>
    {
        public IQueryable<ProductSummary> GetProductSummaryList()
        {
            return from p in this.ObjectContext.Products
                   select new ProductSummary()
                   {
                       ID = p.ProductID,
                       Name = p.Name,
                       Number = p.ProductNumber,
                       ListPrice = p.ListPrice,
                       ThumbnailPhoto = p.ProductProductPhotoes.FirstOrDefault().
                                                        ProductPhoto.ThumbNailPhoto,
                       QuantityAvailable = p.ProductInventories
                                            .Sum(pi => pi.Quantity),
                       Category = p.ProductSubcategory.ProductCategory.Name,
                       Subcategory = p.ProductSubcategory.Name,
                       Model = p.ProductModel.Name,
                       MakeFlag = p.MakeFlag,
                       ModifiedDate = p.ModifiedDate
                   };
        }

        public void InsertProductSummary(ProductSummary productSummary)
        {
            Product product = new Product();
            product.Name = productSummary.Name;
            product.ProductNumber = productSummary.Number;
            product.ListPrice = productSummary.ListPrice;
            product.ModifiedDate = DateTime.Now;

            // Need to set default values for these properties, 
            // otherwise the save will fail
            product.SellStartDate = DateTime.Now;
            product.SafetyStockLevel = 1;
            product.ReorderPoint = 1;

            this.ObjectContext.Products.AddObject(product);
            this.ObjectContext.SaveChanges();

            ChangeSet.Associate(productSummary, product, UpdateProductSummaryValues);

        }

        public void UpdateProductSummary(ProductSummary productSummary)
        {
            Product product = this.ObjectContext.Products
                .Where(p => p.ProductID == productSummary.ID)
                .First();

            product.Name = productSummary.Name;
            product.ProductNumber = productSummary.Number;
            product.ListPrice = productSummary.ListPrice;
            product.ModifiedDate = DateTime.Now;
        }

        public void DeleteProductSummary(ProductSummary productSummary)
        {
            Product product = new Product();
            product.ProductID = productSummary.ID;
            product.ModifiedDate = productSummary.ModifiedDate;
            this.ObjectContext.AttachTo("Products", product);
            this.ObjectContext.DeleteObject(product);
        }

        private void UpdateProductSummaryValues(ProductSummary productSummary, Product product)
        {
            productSummary.ID = product.ProductID;
            productSummary.ModifiedDate = product.ModifiedDate;
        }
    }
}


