CHAPTER 8 SAMPLE CODE
---------------------

This solution accompanies Chapter 8 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Practicing with Server-Side Security - Part 2 (Implementing Security Restrictions)

- Practicing with Client-Side Security


When using this sample, you will find that when you navigate to the product list, you will 
receive an "Access Denied" error unless you've logged in first. Normally you'd prevent
users from navigating to the page altogether unless they're logged in, but this shows you
what happens if they try to load the products from the server anyway. Once you login, the
Administration menu will appear, and will allow you to navigate to the view.

The security will be disabled in the samples for future chapters so that it doesn't 
interfere with you playing with the samples.

--------------------------------------------------------------------------------------
For these samples to work, you will need to have performed the steps covered in Part 1
of the "Practicing with Server-Side Security" workshop to configure the AdventureWorks 
database with the ASP.NET membership tables, and set up users and roles.
--------------------------------------------------------------------------------------

NOTE: You will need to point the entity model to where it can find the AdventureWorks
      database on your machine. Look in the Web.config file in the AdventureWorks.Web
      project. You will find a connection string named AdventureWorksEntities. Change
      this to point to the database on your machine.