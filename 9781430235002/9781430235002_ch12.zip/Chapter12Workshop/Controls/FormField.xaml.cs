﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace Chapter12Workshop.Controls
{
    public partial class FormField : UserControl, INotifyPropertyChanged
    {
        public FormField()
        {
            InitializeComponent();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        // Standard properties - commented out in favour of the dependency properties below
        //private string _label = "";
        //private string _value = "";

        //public string Label
        //{
        //    get { return _label; }
        //    set
        //    {
        //        _label = value;
        //        OnPropertyChanged("Label");
        //    }
        //}

        //public string Value
        //{
        //    get { return _value; }
        //    set
        //    {
        //        _value = value;
        //        OnPropertyChanged("Value");
        //    }
        //}

        // Dependency properties


        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(FormField), null);


        public string Value
        {
            get { return (string)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(string), typeof(FormField), null);
    }
}
