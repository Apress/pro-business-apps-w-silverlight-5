﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace MyControlLibrary
{
    [TemplateVisualState(Name = StateInactive, GroupName = StateGroupCommon)]
    [TemplateVisualState(Name = StateActive, GroupName = StateGroupCommon)]
    [TemplateVisualState(Name = StateStatic, GroupName = StateGroupCommon)]
    [TemplatePart(Name = "Ellipse1", Type = typeof(Ellipse))]
    public class WaitIndicator : Control
    {
        #region Constants
        private const string StateActive = "Active";
        private const string StateInactive = "Inactive";
        private const string StateStatic = "Static";
        private const string StateGroupCommon = "CommonStates";
        #endregion

        public WaitIndicator()
        {
            this.DefaultStyleKey = typeof(WaitIndicator);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            SetVisualState();
        }

        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        public static readonly DependencyProperty IsBusyProperty =
           DependencyProperty.Register("IsBusy", typeof(bool), typeof(WaitIndicator), 
           new PropertyMetadata(false, new PropertyChangedCallback(IsBusyPropertyChanged)));

        private static void IsBusyPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((WaitIndicator)d).SetVisualState();
        }

        private void SetVisualState()
        {
            if (DesignerProperties.IsInDesignTool)
                VisualStateManager.GoToState(this, StateStatic, true);
            else
                VisualStateManager.GoToState(this, IsBusy ? StateActive : StateInactive, true);
        }
    }
}
