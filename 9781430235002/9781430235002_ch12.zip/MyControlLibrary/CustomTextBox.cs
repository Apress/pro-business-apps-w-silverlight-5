﻿using System.Windows;
using System.Windows.Controls;

namespace MyControlLibrary
{
    public class CustomTextBox : TextBox
    {
        protected override void OnGotFocus(RoutedEventArgs e)
        {
            base.OnGotFocus(e);
            this.SelectAll();
        }
    }
}
