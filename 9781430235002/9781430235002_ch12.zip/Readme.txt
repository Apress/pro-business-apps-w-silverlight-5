CHAPTER 12 SAMPLE CODE
----------------------

This solution accompanies Chapter 12 of Pro Business Applications with Silverlight 5, and
includes code for the following workshops:

- Creating a Simple User Control
- Implementing Standard Properties
- Consuming the Properties in the Presentation Layer
- Creating a Dependency Property
- Creating the Base of a Custom Control
- Specifying the Base State
- Defining Visual States and Visual State Groups
- Implementing the �Static� Visual State
- Implementing the �Active� Visual State
- Implementing the WaitIndicator�s Behavior

In addition, code for the CustomTextBox and GroupBox controls discussed in the
chapter are also included here.